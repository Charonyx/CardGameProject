อัปโค้ดตรงนี้นะ เจ้าอร

May the force be with u.
